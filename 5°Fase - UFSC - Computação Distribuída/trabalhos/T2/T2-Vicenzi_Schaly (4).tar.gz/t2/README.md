## Execução

Não foram adicionadas dependências externas.

São necessários três clientes sendo executados para o funcionamento do projeto.

### Com poetry

Utilizamos `Poetry` para gerenciar dependências e ambientes. Para executar o projeto localmente, o ambiente pode ser instalado utilizando o `Poetry`. Caso não possua ele instalado, o [tutorial da documentação do Poetry](https://python-poetry.org/docs/) pode ser seguido.
Tendo o Poetry instalado, basta rodar o seguinte comando para instalar as dependências:

`poetry install`


O projeto pode ser executado com ajuda do _makefile_ para uma execução mais simples.

- make server
    Para iniciar o servidor

- make client
    Para iniciar um cliente


### Sem poetry

Para executar sem a ajuda do __makefile__ e do `poetry`, basta rodar com

`python t2/server.py` e `python t2/client.py`.
