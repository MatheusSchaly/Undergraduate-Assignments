import socket, pickle, os
from _thread import *
from process import Process
import time

n_clients = 0
max_n_clients = 3
available_ids = list(range(0, max_n_clients))
processes = []
connections = {}
first_round = False
voting = False
second_round = False


def create_message(step, identifier, subject):
    return {"step": step, "identifier": identifier, "subject": subject}


def display_processess(processes):
    print("===============================")
    for proc in processes:
        print(
            f"Process {proc.identifier}, next => {proc.next_process}, voting => {proc.voting}, leader => {proc.leader}"
        )
    print("===============================")


def send_message(connections, process, step, identifier, subject):
    next_id = process.next_process
    next_addr = connections[next_id]
    msg = create_message(step, identifier, subject)
    next_addr.sendall(pickle.dumps(msg))


def threaded_client(connection):
    global n_clients
    global max_n_clients
    global available_ids
    global processes
    global connections
    global first_round
    global voting
    global second_round
    if available_ids:
        while True:
            time.sleep(0.5)
            client_message = pickle.loads(connection.recv(1048576))
            print(f"(SERVER) string: {client_message}")
            if client_message["step"] == "create":
                # Send available id
                print(f"(SERVER) available_ids: {available_ids}")
                next_id = available_ids.pop(0)
                process = Process(next_id, None)
                connections[next_id] = connection
                connection.sendall(pickle.dumps(process))

                creation_process_message = pickle.loads(connection.recv(1048576))
                print(f"(SERVER) string: {creation_process_message['step']}")

                # Add process to process list
                if not processes:
                    processes.append(process)
                else:
                    previous = processes[-1]
                    previous.next_process = next_id
                    previous_conn = connections[previous.identifier]
                    msg = create_message("next", None, next_id)
                    previous_conn.send(pickle.dumps(msg))
                    process.next_process = processes[0].identifier
                    msg = create_message("next", None, processes[0].identifier)
                    connection.send(pickle.dumps(msg))
                    processes.append(process)

                # Receive OK

            # Resend string
            # connection.sendall(pickle.dumps(client_message))
            if client_message["step"] == "exit":
                break

            if next_id == 2 and not voting:
                print(f"Process {process.identifier} started a election!")
                process.voting = True
                send_message(
                    connections,
                    process,
                    "first_round",
                    process.identifier,
                    process.identifier,
                )
                first_round = False
                voting = True

            if client_message["step"] == "first_round" and not first_round:
                last_id = client_message["identifier"]
                current_leader_identifier = client_message["subject"]
                print("HERE=>", last_id, current_leader_identifier)
                if int(last_id) == 2:
                    print("(SERVER) Finished first round!")
                    print(
                        f"(SERVER) The elected leader is {current_leader_identifier}!"
                    )
                    first_round = True
                    send_message(
                        connections,
                        process,
                        "second_round",
                        process.identifier,
                        current_leader_identifier,
                    )

                else:
                    process.voting = True
                    if process.identifier > int(current_leader_identifier):
                        current_leader_identifier = process.identifier

                    send_message(
                        connections,
                        process,
                        "first_round",
                        process.identifier,
                        current_leader_identifier,
                    )

            if client_message["step"] == "second_round" and not second_round:
                last_id = client_message["identifier"]
                elected_leader = client_message["subject"]
                print("HERE=>", last_id, elected_leader)
                if int(last_id) == 2:
                    print("(SERVER) Finished second round!")
                    second_round = True
                    msg = create_message("exit", None, None)
                    for conn in connections.values():
                        conn.send(pickle.dumps(msg))
                else:
                    if process.identifier == int(elected_leader):
                        process.leader = True
                        print(
                            f"(SERVER) Process {process.identifier} is the new leader!"
                        )
                        msg = create_message("leader", None, None)
                        connection.send(pickle.dumps(msg))

                    send_message(
                        connections,
                        process,
                        "second_round",
                        process.identifier,
                        elected_leader,
                    )

            if second_round:
                msg = create_message("exit", None, None)
                connection.send(pickle.dumps(msg))

            display_processess(processes)

        print("(SERVER) closing connection")
        n_clients -= 1
        print(f"(SERVER) n_clients: {str(n_clients)}")

        for i in range(len(processes)):
            if processes[i].identifier == process.identifier:
                del processes[i]
                break
        available_ids.append(process.identifier)
        available_ids.sort()
    else:
        print("(SERVER) maximum number of connections reached")
        print("(SERVER) closing connection")
        connection.sendall(str.encode("-1"))
        n_clients -= 1

    connection.close()

    display_processess(processes)


def start_server():
    global n_clients

    server_socket = socket.socket()
    host = "127.0.0.1"
    port = 1276
    try:
        server_socket.bind((host, port))
    except socket.error as e:
        print(str(e))

    print("Waiting for a Connection..")
    server_socket.listen(5)

    while True:
        client, address = server_socket.accept()
        print("(SERVER) connected to: " + address[0] + ":" + str(address[1]))
        start_new_thread(threaded_client, (client,))
        n_clients += 1
        print(f"(SERVER) n_clients: {str(n_clients)}")
    server_socket.close()


if __name__ == "__main__":
    start_server()
