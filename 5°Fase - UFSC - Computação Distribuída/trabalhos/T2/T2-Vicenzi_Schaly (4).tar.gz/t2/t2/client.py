import socket, pickle
from process import Process
import time


def create_message(step, identifier, subject):
    return {"step": step, "identifier": identifier, "subject": subject}


def connect_to_server():
    client_socket = socket.socket()
    host = "127.0.0.1"
    port = 1276

    print("Waiting for connection")
    try:
        client_socket.connect((host, port))
    except socket.error as e:
        print(str(e))
    # client_socket.setblocking(0)
    process = None
    response = ""
    while True:
        # Server is fuull
        if not process:
            # Receive process
            message = create_message("create", None, None)
            client_socket.send(pickle.dumps(message))
            process = pickle.loads(client_socket.recv(1048576))
            message = create_message("OK", None, None)
            client_socket.send(pickle.dumps(message))
        else:
            while True:
                time.sleep(0.5)
                response = pickle.loads(client_socket.recv(1048576))

                if response["step"] == "next":
                    process.next_process = response["subject"]
                    print(
                        f"Process {process.identifier}, next => {process.next_process}, voting => {process.voting}, leader => {process.leader}"
                    )
                    print(f"(CLIENT) response: {response}")
                    # client_socket.send(str.encode(response))

                if response["step"] == "first_round":
                    # Receive response
                    process.voting = True
                    print(f"(CLIENT) response: {response}")
                    client_socket.send(pickle.dumps(response))

                if response["step"] == "second_round":
                    # Receive response
                    process.voting = False
                    print(f"(CLIENT) response: {response}")
                    client_socket.send(pickle.dumps(response))

                if response["step"] == "leader":
                    # Receive response
                    process.leader = True
                    process.voting = False
                    print(f"(CLIENT) I'm the new leader!")
                    client_socket.send(pickle.dumps(response))

                if response["step"] == "exit":
                    process.voting = False
                    print(
                        f"Process {process.identifier}, voting => {process.voting}, leader => {process.leader}"
                    )
                    string = input("awaiting for exit")
                    # break

                if response["step"] == "await!":
                    print("awaiting...")
                    # client_socket.send(str.encode("awaiting..."))

    print("(CLIENT) closing connection")
    client_socket.close()


if __name__ == "__main__":
    connect_to_server()
