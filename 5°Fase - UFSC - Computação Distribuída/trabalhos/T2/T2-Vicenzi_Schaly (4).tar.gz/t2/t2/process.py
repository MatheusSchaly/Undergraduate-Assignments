class Process:
    def __init__(self, identifier, next_process):
        self.identifier = identifier
        self.next_process = next_process
        self.voting = False
        self.leader = False

    def set_voting(self, value):
        print(f"Process {self.identifier} set {value} to voting...")
        self.voting = value
