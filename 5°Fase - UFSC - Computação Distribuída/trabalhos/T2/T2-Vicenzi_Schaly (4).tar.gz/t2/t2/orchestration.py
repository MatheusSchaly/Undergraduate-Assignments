import random
from process import Process


def new_process(previous):
    previous_id = previous.identifier
    new_id = previous_id + 1
    new = Process(new_id, None)
    previous.next_process = new_id
    return new, previous


def display_processess(processes):
    print("===============================")
    for proc in processes:
        print(
            f"Process {proc.identifier}, next => {proc.next_process}, voting => {proc.voting}, leader => {proc.leader}"
        )
    print("===============================")


# lol
def find_process(processes, identifier):
    return processes[identifier]


def c_r_first_round(processes, starting_id):
    already = set()
    print(f"CR First Round! Starting_id = {starting_id}")
    # starting_process = find_process(processes, starting_id)
    identifier = starting_id
    current_leader_identifier = starting_id
    while len(already) != len(processes):
        print(f"Looking now for {identifier}...")
        current_proc = find_process(processes, identifier)
        current_proc.voting = True
        already.add(current_proc.identifier)
        if current_proc.identifier > current_leader_identifier:
            current_leader_identifier = current_proc.identifier
        identifier = current_proc.next_process

    return current_leader_identifier


def c_r_second_round(process, starting_id, elected):
    already = set()
    print(f"CR Second Round! Starting_id = {starting_id}")
    starting_process = find_process(processes, starting_id)
    identifier = starting_process.next_process
    while len(already) != len(processes):
        current_proc = find_process(processes, identifier)
        current_proc.voting = False
        already.add(current_proc.identifier)
        if current_proc.identifier == elected:
            print(f"New leader found! Id = {current_proc.identifier}...")
            current_proc.leader = True
        identifier = current_proc.next_process


def chang_roberts(processes, starting_id):
    elected_leader = c_r_first_round(processes, starting_id)
    display_processess(processes)
    print(f"Elected = {elected_leader}")
    c_r_second_round(processes, starting_id, elected_leader)
    display_processess(processes)


def init():
    num_proc = 5
    processes = []
    print(f"Creating {num_proc} processes...")
    for i in range(num_proc):
        if not processes:
            first_process = Process(i, None)
            processes.append(first_process)
        else:
            new, previous = new_process(processes[-1])
            processes[-1] = previous
            new.next_process = processes[0].identifier
            processes.append(new)
    print("Done!")
    display_processess(processes)
    return processes


def simulation(processes):
    num_proc = len(processes)
    chosen = random.randint(0, num_proc - 1)
    print(f"{chosen} was chosen to start a voting!")
    chang_roberts(processes, chosen)


if __name__ == "__main__":
    print("Starting simulation...")
    processes = init()
    simulation(processes)
