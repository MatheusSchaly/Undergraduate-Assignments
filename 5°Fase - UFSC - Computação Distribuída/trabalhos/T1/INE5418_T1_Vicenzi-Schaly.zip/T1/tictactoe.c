#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include "tictactoe.h"


int check_values(char values[], char bla) {
    for (int i = 0; i < 3; i++) {
        if (values[i] != bla) {
            return 0;
        }
    }
    return 1;
}

/*
    Verify if there's a winner
    0 = not yet
    1 = X
    2 = O
    3 = tie

*/
int verify_board(struct board board) {
    // row check
    for(int i = 0; i < 3; i++) {
        char row[3];
        char col[3];
        for(int j = 0; j < 3; j++) {
            col[j] = board.values[j][i];
            row[j] = board.values[i][j];
        }
        if (check_values(col, 'X') == 1 || check_values(row, 'X')) {
            return 1;
        }
        if (check_values(col, 'O') == 1 || check_values(row, 'O')) {
            return 2;
        }
    }
    // diagonal check
    char diagonal_principal[3];
    char diagonal_secundary[3];
    for (int i = 0; i < 3; i++) {
        diagonal_principal[i] = board.values[i][i];
        diagonal_secundary[i] = board.values[3 - i - 1][i];
    }
    if (check_values(diagonal_principal, 'X') == 1 || check_values(diagonal_secundary, 'X')) {
            return 1;
    }
    if (check_values(diagonal_principal, 'O') == 1 || check_values(diagonal_secundary, 'O')) {
            return 2;
    }

    for(int i = 0; i < 3; i++) {
        for(int j = 0; j < 3; j++) {
            if (board.values[i][j] != 'X' &&  board.values[i][j] != 'O') {
                return 0;
            }
        }
    }
    return 3;
}

void display_board(struct board board) {
    printf("\n----------------------------------------------");
    for(int i = 0; i < 3; i++) {
        char horizontal[3];
        for(int j = 0; j < 3; j++) {
            horizontal[j] = board.values[i][j];
        }
        printf("\n\t %c | %c | %c ", horizontal[0], horizontal[1], horizontal[2]);
    }
    printf("\n----------------------------------------------\n");
}

struct board make_move(struct board board, int index, char value) {
    index--;
    int row = (int) index / 3;
    int col = (int) index % 3;
    board.values[row][col] = value;
    return board;
}

struct board initialize_board() {
    struct board board;
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            board.values[i][j] = (i * 3 + j + 1) + '0';
        }
    }
    return board;
}


void test_check_values() {
    printf("\nStarting to test {check_values}... ");
    char test1[3] = "OOO";
    char test2[3] = "OXO";
    char test3[3] = "O";
    char test4[3] = "XXX";
    assert(check_values(test1, 'X') == 0);
    assert(check_values(test1, 'O') == 1);
    
    assert(check_values(test2, 'X') == 0);
    assert(check_values(test2, '0') == 0);
    
    assert(check_values(test3, 'X') == 0);
    assert(check_values(test3, 'O') == 0);
    
    assert(check_values(test4, 'X') == 1);
    assert(check_values(test4, 'O') == 0);
    printf("Finished!");
}

void test_verify_board() {
    printf("\nStarting to test {verify_board}... ");
    struct board board = initialize_board();
    assert(verify_board(board) == 0);
    board.values[0][0] = 'X';
    board.values[0][1] = 'X';
    board.values[0][2] = 'X';
    assert(verify_board(board) == 1);

    board = initialize_board();
    assert(verify_board(board) == 0);
    board.values[0][0] = 'O';
    board.values[0][1] = 'O';
    board.values[0][2] = 'O';
    assert(verify_board(board) == 2);

    board = initialize_board();
    assert(verify_board(board) == 0);
    board.values[0][1] = 'X';
    board.values[1][1] = 'X';
    board.values[2][1] = 'X';
    assert(verify_board(board) == 1);

    board = initialize_board();
    assert(verify_board(board) == 0);
    board.values[0][1] = 'O';
    board.values[1][1] = 'O';
    board.values[2][1] = 'O';
    assert(verify_board(board) == 2);

    board = initialize_board();
    assert(verify_board(board) == 0);
    board.values[0][0] = 'X';
    board.values[1][1] = 'X';
    board.values[2][2] = 'X';
    assert(verify_board(board) == 1);

    board = initialize_board();
    assert(verify_board(board) == 0);
    board.values[0][2] = 'X';
    board.values[1][1] = 'X';
    board.values[2][0] = 'X';
    assert(verify_board(board) == 1);

    board = initialize_board();
    assert(verify_board(board) == 0);
    board.values[0][0] = 'X';
    board.values[0][1] = 'X';
    board.values[0][2] = 'O';

    board.values[1][0] = 'O';
    board.values[1][1] = 'O';
    board.values[1][2] = 'X';

    board.values[2][0] = 'X';
    board.values[2][1] = 'X';
    board.values[2][2] = 'O';
    assert(verify_board(board) == 3);

    board = initialize_board();
    assert(verify_board(board) == 0);
    board.values[0][0] = 'X';
    board.values[0][1] = 'X';
    board.values[0][2] = 'O';

    board.values[1][0] = 'O';
    board.values[1][1] = 'O';
    board.values[1][2] = 'X';

    board.values[2][0] = 'X';
    board.values[2][1] = 'O';
    board.values[2][2] = 'X';
    assert(verify_board(board) == 3);
    printf("Finished!");
}
// int main() {
//     test_check_values();
//     test_verify_board();
//     struct board board = initialize_board();
//     display_board(board);
//     printf("\n---------------");
//     board = make_move(board, 2, 'X');
//     display_board(board);
//     printf("\n---------------");
//     board = make_move(board, 9, 'O');
//     display_board(board);
//     printf("\n---------------");

//     int result = verify_board(board);

    
//     return 0;
// }
