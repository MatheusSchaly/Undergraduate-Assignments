# INE5418 - Computação Distribuída
## Trabalho 1 - Jogo da Velha Distribuído

### Francisco Vicenzi - 17100516
### Matheus Schaly - 18200436

## Explicação

Detalhes de implementação e decisões de projeto estão presentes no relatório.

## Entrada e Saída

O cliente (`client.c`) possui trẽs decisões básicas: [1] Jogar, [2] Ver pontuações e [3] Sair. Após início de partida, o jogador deve inserir os índices que serão mostrados do tabuleiro.
Imagens e vídeo explicando melhor estão presentes no relatório.

## Instruções

Foi desenvolvido um Makefile para facilitar a execução.
    
    - `make build` compila os arquivos de servidor e cliente;
    - `make clean` remove os arquivos gerados pela compilação;
    - `make all`   executa `clean` e `build`.

Caso não seja do interesse executar via `make`, é possível copiar os comandos diretamente do `Makefile`.

Para rodar o servidor, `./server`; a calculadora, `./client`.

