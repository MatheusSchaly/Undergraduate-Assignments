#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <netinet/in.h>
#include <sys/time.h>

#define PORT 8888


struct message {
    // Message identifier
    // 0 -> server
    // 1 -> peer
    int identifier;
    // Tic tac toe move
    int move;
    // IP/Port/Name/Whatever
    char content[1024];
};

struct message display_scores(struct message message, char names[][32], int scores[], int max_clients) {
    char str_scores[4096];
    char str_score[4];
    strcpy(str_scores, "");
    for (int j = 0; j < max_clients; j++)  {
        if (strcmp(names[j], "EMPTY") != 0) {
            strcat(str_scores, names[j]);
            strcat(str_scores, "\tscore:\t");
            sprintf(str_score, "%d", scores[j]);
            strcat(str_scores, str_score);
            strcat(str_scores, "\n");
            strcpy(message.content, str_scores);
        }
    }
    return message;
}

int main() {
    int server_socket, new_socket, client_socket, current_client_socket, client_sockets[30];
    int i, j, activity, val_read, max_sd, addr_len, max_clients = 30;
    struct sockaddr_in address;
    char buffer[1024];
	char names[max_clients][32];
	int scores[max_clients];
	char str_scores[4096], str_play[4096], str_temp[4096];
	char str_score[4];
	int connected_clients = 0, players_wanting_to_play = 0;
	int waiting_port;
    struct message message;
    struct message client_message;
    int message_len = sizeof(struct message);
    int option = 0;

	// Set all names to EMPTY
	for (i = 0; i < max_clients; i++) {
		strcpy(names[i], "EMPTY");
	}

    // Set of socket descriptors 
    fd_set read_fds;

    char welcome_message[1024] = "Enter you name: ";
    // A message 
    strcpy(message.content, welcome_message);

    // Initialise all client_sockets[] to 0 so not checked 
    for (i = 0; i < max_clients; i++)  {
        client_sockets[i] = 0;
    }

    // Create a server socket
	if ((server_socket = socket(AF_INET, SOCK_STREAM, 0)) == 0) {
		perror("socket failed");
		exit(EXIT_FAILURE);
	}

    // Type of socket created
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = htonl(INADDR_ANY);
    address.sin_port = htons(PORT);

    addr_len = sizeof(address);

	// Bind the socket to localhost port 8888
	if (bind(server_socket, (struct sockaddr *)&address, addr_len) < 0) {
		perror("bind failed");
		exit(EXIT_FAILURE);
	}
	printf("Listener on port %d \n", PORT);

    // Try to specify maximum of 10 pending connections for the server socket
	if (listen(server_socket, 10) < 0) {
		perror("listen");
		exit(EXIT_FAILURE);
	}

	// Accept the incoming connection
	puts("Waiting for connections ...");

    while(1) {
        // Clear the socket set
		FD_ZERO(&read_fds);

        // Add server socket to set
		FD_SET(server_socket, &read_fds);
		max_sd = server_socket;

        // Add child sockets to set
		for (i = 0; i < max_clients; i++) {
			// Socket descriptor
			client_socket = client_sockets[i];
				
			// If valid socket descriptor then add to read list
			if (client_socket > 0) {
                FD_SET(client_socket, &read_fds);
            }
				
			// Highest file descriptor number, need it for the select function
			if (client_socket > max_sd) {
				max_sd = client_socket;
            }
		}

        // Wait for an activity on one of the sockets, timeout is NULL, so wait indefinitely
		activity = select(max_sd + 1, &read_fds, NULL, NULL, NULL);
	
		if ((activity < 0) && (errno != EINTR)) {
			printf("select error");
		}


        // If something happened on the server socket, then its an incoming connection
		if (FD_ISSET(server_socket, &read_fds)) {


			if ((new_socket = accept(server_socket, (struct sockaddr *)&address, (socklen_t*)&addr_len)) < 0) {
				perror("accept");
				exit(EXIT_FAILURE);
			}
			
			// Inform user of socket number - used in send and receive commands
			printf("New connection, socket fd is %d, ip is: %s, port: %d \n", 
                    new_socket, 
                    inet_ntoa(address.sin_addr), 
                    ntohs(address.sin_port)
            );

            strcpy(message.content, welcome_message);
			// Send new connection greeting message
			if (send(new_socket, &message, message_len, 0) != message_len) {
				perror("send");
			}
				
			puts("Asking for name sent successfully");
				
			// Add new socket to array of sockets
			for (i = 0; i < max_clients; i++) {
				// If position is empty
				if (client_sockets[i] == 0) {
					client_sockets[i] = new_socket;
					printf("Adding to list of sockets as %d\n" , i);
					connected_clients++;
					break;
				}
			}

			printf("There are currently %d clients connected to the server\n", connected_clients);
        
        }
        // Else its some IO operation on some other socket
        for (i = 0; i < max_clients; i++) {
			client_socket = client_sockets[i];
			if (FD_ISSET(client_socket, &read_fds)) {
				// Check if it was for closing, and also read the incoming message
                val_read = read(client_socket, &client_message, message_len);
				if (val_read == 0) {
					// Somebody disconnected, get his details and print
					getpeername(client_socket, (struct sockaddr*)&address, (socklen_t*)&addr_len);
					printf("Host disconnected, ip %s, port %d \n", inet_ntoa(address.sin_addr), ntohs(address.sin_port));
					// Close the socket and mark as 0 in list for reuse
					close(client_socket);
					client_sockets[i] = 0;
					scores[i] = 0;
					strcpy(names[i], "EMPTY");
					connected_clients--;
					printf("There are currently %d clients connected to the server\n", connected_clients);
				}
				// Else prompt client for an action
				else {
					printf("Player %d name %s sent the following message: %s\n", client_socket, names[i], client_message.content);
					// If name was not already set then set it
                    option = client_message.identifier;
					if (strcmp(names[i], "EMPTY") == 0) {
						printf("Player %d set his name to %s\n", client_socket, client_message.content);
						strcpy(names[i], client_message.content);
						strcpy(message.content, "Select:\n1 to play\n2 to view scores\n3 to exit\n\r");
						send(client_socket, &message, message_len, 0);
					// User chose to play
					} else if (option == 1) {
                    	printf("Player %d name %s wants to play\n", client_socket, names[i]);
						players_wanting_to_play++;
						// This client will wait for another client to connect
						if (players_wanting_to_play % 2 == 1) {
							// Let the client know that they will be waiting for a worthy opponent
                            message.identifier = -2;
                            message.move = ntohs(address.sin_port);
                            send(client_socket, &message, message_len, 0);
							waiting_port = ntohs(address.sin_port);
							printf("Client %d is waiting for a worthy opponent at port %d\n", client_socket, waiting_port);
						}
						// This user will connect with the client waiting for a connection
						else {
							players_wanting_to_play -= 2;
							printf("Client %d will get connected with another client at port %d\n", client_socket, waiting_port);
                            message.identifier = waiting_port;
                            message.move = 0;
							send(client_socket, &message, message_len, 0);
						}
						printf("There are currently %d players wanting to play\n", players_wanting_to_play);
					// Client chose to view the scores
                	} else if (option == 2) {
                    	printf("Player %d name %s wants to view the scores\n", client_socket, names[i]);
                        message = display_scores(message, names, scores, max_clients);
						send(client_socket, &message, message_len, 0);
					// Client chose to leave
                	} else if (option == 3) {
                    	printf("Player %d name %s wants to leave\n", client_socket, names[i]);
						send(client_socket, &message, message_len, 0);
                    } else if (option == 4) {
						printf("GAME FINISHED WITH A WINNER!\n");
						printf("Player %d, with name %s won!\n", client_socket, names[i]);
						scores[i] += 3;
						printf("Player name %s increased its score by 3, his new score is: %d\n", names[i], scores[i]);
					} else if (option == 5) {
						printf("GAME FINISHED WITH A TIE!\n");
						printf("Tt was a tie! Increasing 1 to player %d' score\n", client_socket);
						scores[i] += 1;
					}
				}
			}
		} 

    }
}