struct board {
    char values[3][3];
};

int check_values(char values[], char bla);
int verify_board(struct board board);
void display_board(struct board board);
struct board make_move(struct board board, int index, char value);
struct board initialize_board();