#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include "tictactoe.h"

#define PORT 8888


struct message {
    // Message identifier
    int identifier;
    // Tic tac toe move
    int move;
    // IP/Port/Name/Whatever
    char content[1024];
};

int display_result(int game_result) {
    if (game_result == 1) {
        printf("\n[CLIENT MESSAGE] WINNER -> [X]\n");
        return 1;
    } else if (game_result == 2) {
        printf("\n[CLIENT MESSAGE] WINNER -> [O]\n");
        return 1;
    } else if (game_result == 3) {
        printf("\n[CLIENT MESSAGE] IT'S A TIE! =(\n");
        return 1;
    }
    return 0;
}

int main() {
    int sockfd, addr_len, result;
    struct sockaddr_in address, wait_address, client_address, peer_address;
    struct message message;
    char str[1024];
    int message_len = sizeof(struct message);
    int waiting_port, is_connected = 0, game_started = 0;
    int peer_sockfd, peer_addr_len, peer_result, peer_port = -1;
    int wait_sockfd, wait_addr_len;
    int client_addr_len, client_sockfd;
    struct board board;
    char tictactoe_char, opponent_tictactoe_char, move_tictactoe_char;
    int moves = 0, turn_identifier = 0;
    int move_input, game_result = 0;
    int server;

    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = inet_addr("127.0.0.1");
    address.sin_port = htons(PORT);
    addr_len = sizeof(address);

    // Connects to server
    result = connect(sockfd, (struct sockaddr *)&address, addr_len);
    if (result == -1) {
        perror("Error on client connection");
        exit(1);
    }

    read(sockfd, &message, message_len);
    // Here client recieves server's request for client's name
    printf("[SERVER MESSAGE] %s\n", message.content);
    
    while(1) {
        if (is_connected) {
            if (game_started) {
                 // TURN IDENTIFIER
                 // 0 -> O, CLIENT TO SERVER
                 // 1 -> X, SERVER TO CLIENT
                if (moves % 2 == turn_identifier) {
                    printf("[CLIENT MESSAGE] It's your turn!\n");
                    scanf("%d", &move_input);
                    printf("[CLIENT MESSAGE] You choose %d!\n", move_input);
                    message.move = move_input;
                    move_tictactoe_char = tictactoe_char;
                    if (turn_identifier == 0) {
                        write(peer_sockfd, &message, message_len);
                    } else {
                        write(client_sockfd, &message, message_len);
                    }
                } else {
                    printf("[CLIENT MESSAGE] Reading opponent's turn...\n");
                    if (turn_identifier == 0) {
                        read(peer_sockfd, &message, message_len);
                    } else {
                        read(client_sockfd, &message, message_len);
                    }
                    printf("[CLIENT MESSAGE] Opponent played %d\n", message.move);
                    move_tictactoe_char = opponent_tictactoe_char;
                }
                moves++;
                board = make_move(board, message.move, move_tictactoe_char);
                printf("[CLIENT MESSAGE] Board after play: \n");
                display_board(board);
                // 0 = not yet
                // 1 = X
                // 2 = O
                // 3 = tie
                game_result = verify_board(board);
                display_result(game_result);
                if (game_result > 0) {
                    game_started = 0;
                    is_connected = 0;
                    moves = 0;
                    if (game_result == 1) {
                        if (turn_identifier == 1) {
                            message.identifier = 4;
                            strcpy(message.content, "I WON! >:)");
                            printf("[CLIENT MESSAGE] Congrats X! Time to send message to main server!\n");
                            write(sockfd, &message, message_len);
                        } else {
                            printf("[CLIENT MESSAGE] You lost to X =( \n");
                            message.identifier = 0;
                        }
                    } else if (game_result == 2) {
                        if (turn_identifier == 0) {
                            message.identifier = 4;
                            strcpy(message.content, "I WON! >:)");
                            printf("[CLIENT MESSAGE] Congrats O! Time to send message to main server!\n");
                            write(sockfd, &message, message_len);
                        } else {
                            printf("[CLIENT MESSAGE] You lost to O =( \n");
                            message.identifier = 0;
                        }  
                    } else {
                        printf("\n[CLIENT MESSAGE] It's a tie. Me and my peer will ask for the server to increase our scores by 1\n");
                        message.identifier = 5;
                        strcpy(message.content, "It was a tie... I'll win next time >:)");
                        write(sockfd, &message, message_len);
                    }
                    if (server) {
                        printf("[CLIENT MESSAGE] Your peer is closing the connection, you are not a server anymore\n");
                        close(client_sockfd);
                    } else {
                        printf("[CLIENT MESSAGE] You are not connected to your peer server anymore\n");
                        close(peer_sockfd);
                    }
                }
            } else {
                printf("[CLIENT MESSAGE] Here is the game board.\n");
                printf("[CLIENT MESSAGE] In order to play, please select an available square (the numbered ones).\n");
                printf("[CLIENT MESSAGE] Your symbol is [%c].\n", tictactoe_char);
                board = initialize_board();
                display_board(board);
                printf("\n[CLIENT MESSAGE] Game started!\n");
                game_started = 1;
            }

        } else {
            memset(str, 0, sizeof str);
            gets(str);
            // Client chose to play
            if (strcmp(str, "1") == 0) {
                printf("[CLIENT MESSAGE] You chose %s, you chose to play\n", str);
                message.identifier = 1;
                strcpy(message.content, "1");
                write(sockfd, &message, message_len);
                read(sockfd, &message, message_len);
                peer_port = message.identifier;
                waiting_port = message.move;
                // If peer_port == -2, then this client will be waiting for a peer connection
                if (peer_port == -2) {
                    wait_sockfd = socket(AF_INET, SOCK_STREAM, 0);
                    wait_address.sin_family = AF_INET;
                    wait_address.sin_addr.s_addr = inet_addr("127.0.0.1");
                    wait_address.sin_port = waiting_port;
                    wait_addr_len = sizeof(wait_address);

                    bind(wait_sockfd, (struct sockaddr *)&wait_address, wait_addr_len);
                    listen(wait_sockfd, 1);
                    printf("[CLIENT MESSAGE] Waiting for a worthy opponent at port %d\n", waiting_port);
                    client_addr_len = sizeof(client_address);
                    client_sockfd = accept(wait_sockfd, (struct sockaddr *)&client_address, &client_addr_len);
                    if (client_sockfd < 0) {
                        perror("accept");
                        exit(EXIT_FAILURE);
                    }
                    printf("[CLIENT MESSAGE] You are now connected to %d\n", waiting_port);
                    is_connected = 1;
                    tictactoe_char = 'X';
                    turn_identifier = 1;
                    opponent_tictactoe_char = 'O';
                    server = 1;

                // Else this client will be connecting to the waiting client
                } else if (peer_port != -1) {
                    printf("[CLIENT MESSAGE] Trying to connect at port %d\n", peer_port);

                    peer_sockfd = socket(AF_INET, SOCK_STREAM, 0);
                    peer_address.sin_family = AF_INET;
                    peer_address.sin_addr.s_addr = inet_addr("127.0.0.1");
                    peer_address.sin_port = peer_port;
                    peer_addr_len = sizeof(peer_address);

                    peer_result = connect(peer_sockfd, (struct sockaddr *)&peer_address, peer_addr_len);

                    if (peer_result == -1) {
                        perror("Error on client connection");
                        exit(1);
                    }
                    printf("[CLIENT MESSAGE] Connected!\n");
                    is_connected = 1;
                    tictactoe_char = 'O';
                    turn_identifier = 0;
                    opponent_tictactoe_char = 'X';
                    server = 0;
                }

            // Client chose to view the scores
            } else if (strcmp(str, "2") == 0) {
                printf("[CLIENT MESSAGE] You chose to view the scores\n");
                message.identifier = 2;
                strcpy(message.content, "2");
                write(sockfd, &message, message_len);
                read(sockfd, &message, message_len);
                printf("[SERVER MESSAGE] Scores:\n%s-------------------------\n", message.content);
            // Client chose to leave
            } else if (strcmp(str, "3") == 0) {
                printf("[CLIENT MESSAGE] You chose %s, you chose to leave\n", str);
                message.identifier = 3;
                strcpy(message.content, str);
                write(sockfd, &message, message_len);
                break;
            // Workaround for string input in C, it receives a new line eveytime
            } else if (strcmp(str, "") == 0){
                ;
            // Only show message received from server and write to it
            } else {
                strcpy(message.content, str);
                write(sockfd, &message, message_len);
                read(sockfd, &message, message_len);
                printf("[SERVER MESSAGE]:\n%s", message.content);
            }
        }
    }
    // write(sockfd, &str, 1024);
    printf("[CLIENT MESSAGE] Client closing connection\n");
    close(sockfd);
	exit(0);
}