import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject; 

public class Counter extends UnicastRemoteObject implements CounterInterface{
	int count;
	
	public Counter() throws RemoteException {
		int count = 1;
	}
	
	@Override
	public int getCount() throws RemoteException {
		synchronized (this) {
			return count += 1;
		}
	}

}
